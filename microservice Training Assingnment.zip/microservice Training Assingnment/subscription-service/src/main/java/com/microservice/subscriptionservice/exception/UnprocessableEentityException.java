package com.microservice.subscriptionservice.exception;

public class UnprocessableEentityException extends RuntimeException{
    private static final long serialVersionUID = 1L;
}
