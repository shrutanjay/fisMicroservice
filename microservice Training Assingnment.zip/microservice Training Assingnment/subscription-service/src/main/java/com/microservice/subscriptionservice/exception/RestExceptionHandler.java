package com.microservice.subscriptionservice.exception;


import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class RestExceptionHandler extends ResponseEntityExceptionHandler {
    public static final String REQ_NOT_PROCESSED = "Request not processed successfully";
    @ExceptionHandler(UnprocessableEentityException.class)
    public ResponseEntity<Object> exception(UnprocessableEentityException exception) {
        return new ResponseEntity<>(this.getCustomHttpError(HttpStatus.UNPROCESSABLE_ENTITY), HttpStatus.UNPROCESSABLE_ENTITY);
    }

    private HttpError getCustomHttpError(HttpStatus status){
        return new HttpError(status,this.REQ_NOT_PROCESSED);
    }
}
