package com.microservice.subscriptionservice.service;


import com.microservice.subscriptionservice.model.Subscription;

import java.util.List;

public interface SubscriptionService {
  List<Subscription> getSubscriptionsList();


  Subscription save(Subscription subscriptionSave);
}
