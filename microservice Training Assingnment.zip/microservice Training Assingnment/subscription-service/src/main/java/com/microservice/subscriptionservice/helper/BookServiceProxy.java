package com.microservice.subscriptionservice.helper;

import com.microservice.subscriptionservice.model.Book;
import com.microservice.subscriptionservice.model.BookDTO;
import feign.RequestLine;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@FeignClient(name="book-service" , url="http://localhost:8082")
public interface BookServiceProxy {
    String baseurl="http://localhost:8082";

    @GetMapping("/book/booklist")
    public ResponseEntity<List<Book>> getbooklist() ;

}
