package com.microservice.subscriptionservice.model;


import lombok.Data;

import javax.persistence.Column;

@Data
public class BookDTO {

    private String bookId;

    private String bookName ;

    private String author;

    private int copiesAvailable ;

    private int totalCopies;


}
