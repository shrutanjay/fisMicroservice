package com.microservice.subscriptionservice.controller;

import com.microservice.subscriptionservice.model.Subscription;
import com.microservice.subscriptionservice.service.SubscriptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import java.util.List;

@RestController
@RequestMapping("/subscriptions")
public class SubscriptionController {
    @Autowired
    RestTemplate restTemplate;
    private final String URI_USERS = "/api/booklist";
    @Autowired
    SubscriptionService subscriptionService;

    @GetMapping("/subscriptionslist")
    public ResponseEntity<List<Subscription>> getAllsubscriptions() {
        try {

            List<Subscription> subscriptionsList = subscriptionService.getSubscriptionsList();
            return new ResponseEntity<>(subscriptionsList, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/save")
    public ResponseEntity<?> save(@RequestBody Subscription subscription) {

        Subscription subscriptionSave = subscriptionService.save(subscription);
        return ResponseEntity.ok().body(subscriptionSave);

    }
}
