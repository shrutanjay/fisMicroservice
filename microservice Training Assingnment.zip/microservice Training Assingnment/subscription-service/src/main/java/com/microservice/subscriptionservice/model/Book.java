package com.microservice.subscriptionservice.model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "book")
@Data
public class Book {

	@Id

	@Column(name = "BOOK_ID")
	private String bookId;

	@Column(name = "BOOK_NAME")
	private String bookName ;

	@Column(name = "AUTHOR")
	private String author;

	@Column(name = "AVAILABLE_COPIES")
	private int copiesAvailable ;

	@Column(name = "TOTAL_COPIES")
	private int totalCopies;

	public Book() {

	}

//	public book(String title, String description, boolean published) {
//		this.title = title;
//		this.description = description;
//		this.published = published;
//	}

}
