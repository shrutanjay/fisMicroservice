package com.microservice.subscriptionservice.exception;


import lombok.Data;
import org.springframework.http.HttpStatus;

@Data
public class HttpError {
    private HttpStatus status;

    private String errorMessage;

    public HttpError(HttpStatus status,String errorMessage) {
        super();
        this.status = status;
        this.errorMessage = errorMessage;
    }

}
