package com.microservice.subscriptionservice.service;

import com.microservice.subscriptionservice.exception.UnprocessableEentityException;
import com.microservice.subscriptionservice.helper.BookServiceProxy;
import com.microservice.subscriptionservice.model.Book;
import com.microservice.subscriptionservice.model.BookDTO;
import com.microservice.subscriptionservice.model.Subscription;
import com.microservice.subscriptionservice.repository.SubscriptionRepository;
//import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import feign.Feign;
import feign.Logger;
import feign.gson.GsonDecoder;
import feign.gson.GsonEncoder;
import feign.okhttp.OkHttpClient;
import feign.slf4j.Slf4jLogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;
@Service
public class SubscriptionServiceImpl implements SubscriptionService {
    private final String URI_USERS = "/api/booklist";

    @Autowired()
    SubscriptionRepository subscriptionRepository;
    @Autowired
    RestTemplate restTemplate;
    @Autowired
    private BookServiceProxy bookServiceProxy;
    @Override
    public List<Subscription> getSubscriptionsList() {
        return subscriptionRepository.findAll();
    }


    //USING REST_TEMPLATE
 /*   @Override
    @Transactional
    public Subscription save(Subscription subscriptionSave)  {

          ResponseEntity<List<BookDTO>> bookDTOS = this.getdetails();

          for (int i = 0; i < bookDTOS.getBody().size(); i++) {
              BookDTO book = (BookDTO) bookDTOS.getBody().get(i);

              if (book.getBookId().contains(subscriptionSave.getBookId()) && book.getCopiesAvailable() > 0) {
                  System.out.println("book is availablefo subscription");
                  return subscriptionRepository.save(subscriptionSave);
              } else {
                  System.out.println("book is not available for subscription");
                  throw new UnprocessableEentityException();
              }
          }

        return subscriptionSave;
    }*/
    public ResponseEntity<List<BookDTO>> getdetails() {
        BookDTO[] usersArray = restTemplate.getForObject(URI_USERS, BookDTO[].class);
        return new ResponseEntity<>(Arrays.asList(usersArray), HttpStatus.OK);
    }


    //USING feign
    @Override
    @Transactional
    @HystrixCommand(fallbackMethod = "getBookServiceFallbackStatus")
    public Subscription save(Subscription subscriptionSave) {
        ResponseEntity<List<Book>> bookDTOS = bookServiceProxy.getbooklist();

        for (int i = 0; i < bookDTOS.getBody().size(); i++) {
            Book book = bookDTOS.getBody().get(i);
            if (book.getBookId().contains(subscriptionSave.getBookId()) && book.getCopiesAvailable() > 0) {
                return subscriptionRepository.save(subscriptionSave);
            } else {
                throw new UnprocessableEentityException();
            }
        }
        return subscriptionSave;
    }

    public Subscription getBookServiceFallbackStatus(Subscription subscriptionSave){
        Subscription subscription = new Subscription();
        subscription.setBookServiceMessage("Book-Service is down can't create subscription records");

        return subscription;
    }
}
