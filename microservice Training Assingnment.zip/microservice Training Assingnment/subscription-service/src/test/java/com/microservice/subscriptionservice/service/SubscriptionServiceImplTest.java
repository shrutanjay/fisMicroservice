package com.microservice.subscriptionservice.service;

import com.microservice.subscriptionservice.helper.BookServiceProxy;
import com.microservice.subscriptionservice.mockUtils.MockUtils;
import com.microservice.subscriptionservice.model.Book;
import com.microservice.subscriptionservice.model.Subscription;
import com.microservice.subscriptionservice.repository.SubscriptionRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@SpringBootTest
@ActiveProfiles("test")
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class SubscriptionServiceImplTest {

	@MockBean
	SubscriptionRepository subscriptionRepository;
	@MockBean
	SubscriptionServiceImpl SubscriptionServiceImpl;
	@MockBean
	BookServiceProxy bookServiceProxy;

	@Test
	void testGetSubscriptionsList() {
		java.sql.Date date=new java.sql.Date(2014, 02, 11);

		java.sql.Date date2=new Date(2023, 12, 12);
		List<Subscription> subscriptionList = MockUtils.subscriptionMockList();
		when(subscriptionRepository.findAll()).thenReturn(subscriptionList);

		List<Subscription> subscriptions = this.subscriptionRepository.findAll();

		Assertions.assertNotNull(subscriptions);
		Assertions.assertEquals(2,subscriptions.size());
		Assertions.assertEquals("b1", subscriptions.get(0).getBookId());
		Assertions.assertEquals("Iru", subscriptions.get(0).getSubscriberName());
		Assertions.assertEquals(date, subscriptions.get(0).getDateReturned());
		Assertions.assertEquals(date, subscriptions.get(0).getDateSubscribed());

		Assertions.assertEquals("b2", subscriptions.get(1).getBookId());
		Assertions.assertEquals("james", subscriptions.get(1).getSubscriberName());
		Assertions.assertEquals(date2, subscriptions.get(1).getDateReturned());
		Assertions.assertEquals(date2, subscriptions.get(1).getDateSubscribed());

	}

	@Test
	void testGetBookList_WithNull() {

		List<Subscription> subscriptionList = new ArrayList<>();
		when(subscriptionRepository.findAll()).thenReturn(subscriptionList);

		List<Subscription> subscription = this.subscriptionRepository.findAll();
		Assertions.assertEquals(0, subscription.size());
		Assertions.assertEquals(subscriptionList, subscription);

	}

//	@Test
//	void testSave(){
//		ResponseEntity<List<Book>> booKList = (ResponseEntity<List<Book>>) MockUtils.bookMockList();
//		List<Subscription> subscriptionList = MockUtils.subscriptionMockList();
//		when(bookServiceProxy.getbooklist()).thenReturn( booKList);
//		when (subscriptionRepository.save (any (Subscription.class))).thenReturn ((Subscription) subscriptionList);
//
//
//		Assertions.assertNotNull(subscriptionList);
//
////		Assertions.assertEquals("b12", booKList.get(0).getBookId());
//		Assertions.assertEquals("b12", booKList.getBody(0).g;
//		Assertions.assertEquals("thinkGroov", booKList.get(0).getBookName());
//		Assertions.assertEquals("Iru", booKList.get(0).getAuthor());
//		Assertions.assertEquals(20, booKList.get(0).getCopiesAvailable());
//		Assertions.assertEquals(25, booKList.get(0).getTotalCopies());
//
//		Assertions.assertEquals("b2", booKList.get(1).getBookId());
//		Assertions.assertEquals("testbook", booKList.get(1).getBookName());
//		Assertions.assertEquals("James", booKList.get(1).getAuthor());
//		Assertions.assertEquals(30, booKList.get(1).getCopiesAvailable());
//		Assertions.assertEquals(40, booKList.get(1).getTotalCopies());
//	}
}