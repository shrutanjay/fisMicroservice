package com.microservice.subscriptionservice.mockUtils;


import com.microservice.subscriptionservice.model.Book;
import com.microservice.subscriptionservice.model.Subscription;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class MockUtils {
	public static List<Subscription> subscriptionMockList() {

		List<Subscription> subscriptionList = new ArrayList();
		Date date=new Date(2014, 02, 11);
		Subscription subscription1 = new Subscription();
		subscription1.setBookId("b1");
		subscription1.setSubscriberName("Iru");
		subscription1.setDateReturned(date);
		subscription1.setDateSubscribed(date);
		subscriptionList.add(subscription1);

		Date date1=new Date(2023, 12, 12);
		Subscription subscription2 = new Subscription();
		subscription2.setBookId("b2");
		subscription2.setSubscriberName("james");
		subscription2.setDateReturned(date1);
		subscription2.setDateSubscribed(date1);
		subscriptionList.add(subscription2);

		return subscriptionList;
	}

	public static List<Book> bookMockList() {

		List<Book> bookList = new ArrayList();

		Book book1 = new Book();
		book1.setBookId("b12");
		book1.setBookName("thinkGroov");
		book1.setAuthor("Iru");
		book1.setCopiesAvailable(20);
		book1.setTotalCopies(25);
		bookList.add(book1);
		Book book2 = new Book();
		book2.setBookId("b2");
		book2.setBookName("testbook");
		book2.setAuthor("James");
		book2.setCopiesAvailable(30);
		book2.setTotalCopies(40);
		bookList.add(book2);
		return bookList;
	}

}
