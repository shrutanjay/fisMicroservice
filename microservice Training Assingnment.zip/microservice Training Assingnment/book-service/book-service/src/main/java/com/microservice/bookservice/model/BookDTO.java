package com.microservice.bookservice.model;


import lombok.Data;

import java.util.List;

@Data
public class BookDTO {

    List<Book> blist;
    private long  ID;

    private String bookId;

    private String bookName ;

    private String author;

    private int availableCopies;

    private int totalCopies;


}
