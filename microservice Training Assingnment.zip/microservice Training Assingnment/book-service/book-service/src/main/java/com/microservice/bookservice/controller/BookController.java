package com.microservice.bookservice.controller;

import com.microservice.bookservice.model.Book;
import com.microservice.bookservice.model.BookDTO;
import com.microservice.bookservice.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/book")
public class BookController {


	@Autowired
	BookService bookService;

	@GetMapping("/booklist")
	public ResponseEntity<List<Book>> getbooklist() {
		try {

			List<Book> bookList= bookService.getBookList();

			return new ResponseEntity<>(bookList, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
