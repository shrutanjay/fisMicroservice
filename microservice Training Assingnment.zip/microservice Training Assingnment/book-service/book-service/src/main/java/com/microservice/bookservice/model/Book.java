package com.microservice.bookservice.model;

import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "book")
@Data
public class Book {

	@Id
	@Column(name = "BOOK_ID")
	private String bookId;

	@Column(name = "BOOK_NAME")
	private String bookName ;

	@Column(name = "AUTHOR")
	private String author;

	@Column(name = "AVAILABLE_COPIES")
	private int copiesAvailable ;

	@Column(name = "TOTAL_COPIES")
	private int totalCopies;



	public void book(String bookId, String bookName, String author, int copiesAvailable, int totalCopies) {
		this.bookId = bookId;
		this.bookName = bookName;
		this.author = author;
		this.copiesAvailable = copiesAvailable;
		this.totalCopies = totalCopies;
	}

}
