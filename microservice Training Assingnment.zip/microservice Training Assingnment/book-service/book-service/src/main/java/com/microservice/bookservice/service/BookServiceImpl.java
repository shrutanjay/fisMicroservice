package com.microservice.bookservice.service;

import com.microservice.bookservice.model.Book;
import com.microservice.bookservice.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class BookServiceImpl implements BookService {

    @Autowired()
    BookRepository bookRepository;
    @Override
    public List<Book> getBookList() {

        return bookRepository.findAll();
    }

}
