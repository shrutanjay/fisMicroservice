package com.microservice.bookservice.mockUtils;

import com.microservice.bookservice.model.Book;

import java.util.ArrayList;
import java.util.List;

public class MockUtils {
	public static List<Book> bookMockList() {

		List<Book> bookList = new ArrayList();

		Book book1 = new Book();
		book1.setBookId("b12");
		book1.setBookName("thinkGroov");
		book1.setAuthor("Iru");
		book1.setCopiesAvailable(20);
		book1.setTotalCopies(25);
		bookList.add(book1);
		Book book2 = new Book();
		book2.setBookId("b2");
		book2.setBookName("testbook");
		book2.setAuthor("James");
		book2.setCopiesAvailable(30);
		book2.setTotalCopies(40);
		bookList.add(book2);
		return bookList;
	}
}
