package com.microservice.bookservice.service;

import com.microservice.bookservice.mockUtils.MockUtils;
import com.microservice.bookservice.model.Book;
import com.microservice.bookservice.repository.BookRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;

@SpringBootTest
@ActiveProfiles("test")
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class BookServiceImplTest {
    @MockBean
    BookRepository bookRepository;
    @MockBean
    BookServiceImpl bookServiceImpl;

    @Test
    void testGetBookList() {
        List<Book> booKList = MockUtils.bookMockList();
        when(bookRepository.findAll()).thenReturn(booKList);

        List<Book> book = this.bookRepository.findAll();

        Assertions.assertNotNull(book);

        Assertions.assertEquals("b12", book.get(0).getBookId());
        Assertions.assertEquals("thinkGroov", book.get(0).getBookName());
        Assertions.assertEquals("Iru", book.get(0).getAuthor());
        Assertions.assertEquals(20, book.get(0).getCopiesAvailable());
        Assertions.assertEquals(25, book.get(0).getTotalCopies());

        Assertions.assertEquals("b2", book.get(1).getBookId());
        Assertions.assertEquals("testbook", book.get(1).getBookName());
        Assertions.assertEquals("James", book.get(1).getAuthor());
        Assertions.assertEquals(30, book.get(1).getCopiesAvailable());
        Assertions.assertEquals(40, book.get(1).getTotalCopies());
    }

    @Test
    void testGetBookList_WithNull() {

        List<Book> booKList = new ArrayList<>();
        when(bookRepository.findAll()).thenReturn(booKList);

        List<Book> book = this.bookRepository.findAll();
        Assertions.assertEquals(0, book.size());
        Assertions.assertEquals(booKList, book);

    }
}
