package com.microservice.bookservice.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.jayway.jsonpath.TypeRef;
import com.microservice.bookservice.model.Book;
import com.microservice.bookservice.model.BookDTO;
import com.microservice.bookservice.service.BookService;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.math.BigDecimal;
import java.util.*;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class BookControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    BookService bookService;
    private ObjectMapper mapper = new ObjectMapper();

    @Test
    void testGetbooklist() throws Exception {
        List<Book> booklist = this.bookMockList();
        when(bookService.getBookList()).thenReturn(booklist);
//    String apiResponse="[{"bookId":"b12","bookName":"thinkGroov","author":"Iru","copiesAvailable":20,"totalCopies":25}]";
        MvcResult result = mockMvc.perform(get("/book/booklist")
                        .contentType(MediaType.APPLICATION_JSON_VALUE))
                .andExpect(status().isOk())
                .andReturn();
        List<Book> booklistres = new ArrayList<>();
//        booklistres = (List<Book>) mapper.readValue(result.getResponse().getContentType(), Book.class);
//        List<BookDTO> booklistres = mapper.readValue(result.getResponse().getContentAsString(), Book.class);
//       BookDTO b=mapper.readValue(result.getResponse().getContentAsString(),BookDTO.class).;

//        Assertions.assertEquals("b12",  result.getResponse().getStatus());
        result.getResponse().getStatus();
//        System.out.println("api res"+s);
    }

    public List<Book> bookMockList() {

        List<Book> bookList= new ArrayList();

        Book  book1 = new Book();
        book1.setBookId("b12");
        book1.setBookName("thinkGroov");
        book1.setAuthor("Iru");
        book1.setCopiesAvailable(20);
        book1.setTotalCopies(25);
        bookList.add(book1);
        return bookList;
    }
//public BookDTO bookMockList() {
//
//    List<BookDTO> bookList= new ArrayList();
//
//    Book  book1 = new Book();
//    book1.setBookId("b12");
//    book1.setBookName("thinkGroov");
//    book1.setAuthor("Iru");
//    book1.setCopiesAvailable(20);
//    book1.setTotalCopies(25);
//    bookList.add(book1);
//    return bookList;
//}

}
